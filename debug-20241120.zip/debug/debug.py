import sys
from PyQt6.QtWidgets import QApplication, QLabel, QPushButton, QVBoxLayout, QWidget

def on_button_click():
    label.setText("you click the button")

app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle("PyQt6 demo")
window.resize(300, 200)

layout = QVBoxLayout()

label = QLabel("welcome to use PyQt6！")
layout.addWidget(label)

button = QPushButton("click me")
button.clicked.connect(on_button_click)
layout.addWidget(button)

window.setLayout(layout)
window.show()

sys.exit(app.exec())
